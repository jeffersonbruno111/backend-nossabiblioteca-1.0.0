package br.fafic.ppi.biblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NossaBiblioteca2Application {

	public static void main(String[] args) {
		SpringApplication.run(NossaBiblioteca2Application.class, args);
	}

}
