package br.fafic.ppi.biblioteca.model;

import java.util.UUID;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.fafic.ppi.biblioteca.enums.*;

@Entity
public class Aluno extends Pessoa {
	
	private static final long serialVersionUID = 1L;

	@OneToOne()
	@JsonBackReference(value = "bibliotecaAlunos")
	private Biblioteca biblioteca;
	
	@ManyToOne()
	@JsonBackReference(value = "cursoAlunos")
	private Curso curso;
	
	@Enumerated(EnumType.ORDINAL)
	private Periodo periodo;
	
	public Aluno(UUID id, String nome, String cpf, Genero genero, Endereco endereco, Contato contato, Login login,
			Curso curso, Biblioteca biblioteca) {
		super(id, nome, cpf, genero, endereco, contato, login);
		this.curso = curso;
		this.biblioteca = biblioteca;
	}

	public Aluno() {
		
	}
	
	
	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	
	
	public Biblioteca getBiblioteca() {
		return biblioteca;
	}

	public void setBiblioteca(Biblioteca biblioteca) {
		this.biblioteca = biblioteca;
	}

	public Periodo getPeriodo() {
		return periodo;
	}

	public void setPeriodo(Periodo periodo) {
		this.periodo = periodo;
	}
}
