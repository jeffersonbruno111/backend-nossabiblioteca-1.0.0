package br.fafic.ppi.biblioteca.model;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.*;

import br.fafic.ppi.biblioteca.enums.StatusDevolucao;

@Entity
public class Devolucao implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID id;
	
	@OneToOne
	private Emprestimo emprestimo;
	
	@Temporal(TemporalType.DATE)
	private Date dataDevolucao;
	
	private float valorMulta;
	
	@Enumerated(EnumType.ORDINAL)
	private StatusDevolucao statusDevolucao;

	public Devolucao(UUID id, Emprestimo emprestimo, Date dataDevolucao, float valorMulta, StatusDevolucao statusDevolucao) {
		super();
		this.id = id;
		this.emprestimo = emprestimo;
		this.dataDevolucao = dataDevolucao;
		this.valorMulta = valorMulta;
		this.statusDevolucao = statusDevolucao;
	}
	
	public Devolucao() {
		
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public Emprestimo getEmprestimo() {
		return emprestimo;
	}

	public void setEmprestimo(Emprestimo emprestimo) {
		this.emprestimo = emprestimo;
	}

	public Date getDataDevolucao() {
		return dataDevolucao;
	}

	public void setDataDevolucao(Date dataDevolucao) {
		this.dataDevolucao = dataDevolucao;
	}

	public float getValorMulta() {
		return valorMulta;
	}

	public void setValorMulta(float valorMulta) {
		this.valorMulta = valorMulta;
	}

	public StatusDevolucao getStatusDevolucao() {
		return statusDevolucao;
	}

	public void setStatusDevolucao(StatusDevolucao statusDevolucao) {
		this.statusDevolucao = statusDevolucao;
	}
}
