package br.fafic.ppi.biblioteca.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Emprestimo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID id;
	
	@ManyToOne
	@JsonBackReference(value = "pessoaEmprestimo")
	private Pessoa pessoa;
	
	@ManyToMany(cascade = {CascadeType.REMOVE, CascadeType.MERGE})
	@JoinTable(
			name = "emprestimo_livro",
			joinColumns = {@JoinColumn(name= "emprestimo_id")},
			inverseJoinColumns = @JoinColumn(name = "livro_id")
			)
	private List<Livro> livros;
	
	@Temporal(TemporalType.DATE)
	private Date dataEmprestimo;

	public Emprestimo(UUID id, Pessoa pessoa, List<Livro> livros, Date dataEmprestimo) {
		super();
		this.id = id;
		this.pessoa = pessoa;
		this.livros = livros;
		this.dataEmprestimo = dataEmprestimo;
	}

	public Emprestimo() {
		
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}
	
	public Pessoa getPessoa() {
		return pessoa;
	}
	
	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}
	
	public List<Livro> getLivros() {
		return livros;
	}

	public void setLivros(List<Livro> livros) {
		this.livros = livros;
	}
	
	public Date getDataEmprestimo() {
		return dataEmprestimo;
	}

	public void setDataEmprestimo(Date dataEmprestimo) {
		this.dataEmprestimo = dataEmprestimo;
	}

}
