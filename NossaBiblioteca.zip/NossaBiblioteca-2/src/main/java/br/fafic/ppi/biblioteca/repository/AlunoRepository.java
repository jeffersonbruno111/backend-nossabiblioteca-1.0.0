package br.fafic.ppi.biblioteca.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import br.fafic.ppi.biblioteca.model.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, UUID>{

	Aluno findByNomeContaining(String nome);
	
}
