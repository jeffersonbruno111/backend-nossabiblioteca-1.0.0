package br.fafic.ppi.biblioteca.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import br.fafic.ppi.biblioteca.model.Biblioteca;

public interface BibliotecaRepository extends JpaRepository<Biblioteca, UUID>{

}
