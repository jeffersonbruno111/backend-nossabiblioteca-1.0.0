package br.fafic.ppi.biblioteca.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import br.fafic.ppi.biblioteca.model.Bibliotecario;

public interface BibliotecarioRepository extends JpaRepository<Bibliotecario, UUID> {
	
	List<Bibliotecario> findAllByBibliotecaId(UUID bibliotecaId);
	
}