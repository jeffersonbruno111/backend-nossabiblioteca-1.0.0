package br.fafic.ppi.biblioteca.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.fafic.ppi.biblioteca.model.Devolucao;

public interface DevolucaoRepository extends JpaRepository<Devolucao, UUID> {
	
	Devolucao findFirst1ByEmprestimoPessoaId(UUID pessoaId);

	List<Devolucao> findByEmprestimoPessoaId(UUID pessoaId);
	
	@Query(nativeQuery = true, value = "SELECT * FROM devolucao JOIN emprestimo ON emprestimo.id = devolucao.emprestimo_id JOIN pessoa ON emprestimo.pessoa_id = pessoa.id WHERE pessoa.id = ?1 AND devolucao.status_devolucao = 1")
	List<Devolucao> buscarDevolucoesEmAtrasoPorIdDePessoa(UUID pessoaId);
	
}
