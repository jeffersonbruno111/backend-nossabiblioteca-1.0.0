package br.fafic.ppi.biblioteca.repository;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.fafic.ppi.biblioteca.model.Emprestimo;

public interface EmprestimoRepository extends JpaRepository<Emprestimo, UUID> {
	
	List<Emprestimo> findLivroByPessoaId(UUID id);

	@Query(value = "SELECT COUNT(livro.id) FROM emprestimo_livro JOIN emprestimo ON emprestimo.id = emprestimo_livro.emprestimo_id JOIN livro ON livro.id = emprestimo_livro.livro_id WHERE emprestimo_livro.emprestimo_id = ?1 AND livro.id = ?2", nativeQuery = true)
	long recuperarQuantidadeDeExemplares(UUID emprestimoId, UUID livroId);
	
	@Query(value = "SELECT COUNT(livro.id) FROM emprestimo_livro JOIN emprestimo ON emprestimo.id = emprestimo_livro.emprestimo_id JOIN livro ON livro.id = emprestimo_livro.livro_id WHERE emprestimo_livro.emprestimo_id = ?1", nativeQuery = true)
	long recuperarQuantidadeDeLivrosNoEmprestimo(UUID emprestimoId);
	
	List<Emprestimo> findByPessoaId(UUID pessoaId);
	
	@Query(value = "select e from Emprestimo e join e.pessoa u where u.nome= :nome")
	public List<Emprestimo> findByEmprestimoAluno(String nome);
	
	@Query(value = "SELECT d.dataDevolucao FROM Devolucao as d WHERE d.emprestimo.id = ?1")
	public Date verificarDevolucao(UUID uuid);
	
	
}

