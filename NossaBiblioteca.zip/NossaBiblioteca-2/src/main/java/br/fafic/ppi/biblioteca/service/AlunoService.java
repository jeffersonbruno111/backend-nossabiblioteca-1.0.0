package br.fafic.ppi.biblioteca.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.fafic.ppi.biblioteca.model.Aluno;
import br.fafic.ppi.biblioteca.repository.AlunoRepository;

@Service
public class AlunoService {

	@Autowired
	private AlunoRepository repository;
	
	public Aluno save(Aluno aluno) {
		return repository.save(aluno);
	}
	
	public Optional<Aluno> findById(UUID id) {
		return repository.findById(id);
	}
	
	public Aluno findByNome(String nome) {
		return repository.findByNomeContaining(nome);
	}
	
	public List<Aluno> findAll(){
		return repository.findAll();
	}
	
	public Aluno update(Aluno aluno) {
		return repository.save(aluno);
	}
	
	public boolean delete(UUID id) {
		repository.deleteById(id);
		return true;
	}
}

