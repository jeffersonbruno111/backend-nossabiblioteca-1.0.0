package br.fafic.ppi.biblioteca.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.fafic.ppi.biblioteca.model.Bibliotecario;
import br.fafic.ppi.biblioteca.repository.BibliotecarioRepository;

@Service
public class BibliotecarioService {
	
	@Autowired
	private BibliotecarioRepository repository;
	
	public Bibliotecario save(Bibliotecario bibliotecario) {
		return repository.save(bibliotecario);
	}
	
	public Optional<Bibliotecario> findById(UUID id) {
		return repository.findById(id);
	}
	
	public List<Bibliotecario> findAll(){
		return repository.findAll();
	}
	
	public List<Bibliotecario> findAllByBibliotecaId(UUID bibliotecaId){
		return repository.findAllByBibliotecaId(bibliotecaId);
	}
	
	public Bibliotecario update(Bibliotecario bibliotecario) {
		return repository.save(bibliotecario);
	}
	
	public boolean delete(UUID id) {
		repository.deleteById(id);
		return true;
	}

}

