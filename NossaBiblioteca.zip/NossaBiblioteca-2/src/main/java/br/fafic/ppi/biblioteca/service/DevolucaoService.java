package br.fafic.ppi.biblioteca.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.fafic.ppi.biblioteca.enums.StatusDevolucao;
import br.fafic.ppi.biblioteca.model.Devolucao;
import br.fafic.ppi.biblioteca.model.Emprestimo;
import br.fafic.ppi.biblioteca.repository.DevolucaoRepository;
import br.fafic.ppi.biblioteca.repository.EmprestimoRepository;

@Service
public class DevolucaoService {

	@Autowired
	private DevolucaoRepository repository;
	
	@Autowired
	private EmprestimoRepository emprestimoRepository;
	
	public Devolucao save(Devolucao devolucao) {
		Optional<Devolucao> devolucao2 =  Optional.ofNullable(devolucao);
		return repository.save(devolucao);
	}
	
	public Optional<Devolucao> findById(UUID id) {
		Optional<Devolucao> devolucao = repository.findById(id);
		emAtraso(devolucao);
		return devolucao;
	}
	
	public List<Devolucao> findAll(){
		return repository.findAll();
	}
	
	public Devolucao temPendencia(UUID pessoaId) {
		return repository.findFirst1ByEmprestimoPessoaId(pessoaId);
	}
	
	public boolean emAtraso(Optional<Devolucao> devolucao) {
		Optional<Emprestimo> emprestimo = emprestimoRepository.findById(devolucao.get().getEmprestimo().getId());
		System.out.println("Data emprestimo: " + emprestimo.get().getDataEmprestimo());
		
		LocalDate dataDevolucao = LocalDate.parse(devolucao.get().getDataDevolucao().toString());
		LocalDate dataEmprestimo = LocalDate.parse(emprestimo.get().getDataEmprestimo().toString());
		
		int diasEmAtraso = calcularDiasDeAtraso(dataEmprestimo, dataDevolucao);
		
		if(diasEmAtraso > 3) {
			//System.out.println("Dias em atraso: " + diasEmAtraso);
			int diasParaCalcularMulta = diasEmAtraso - 3;
			//System.out.println("Dias para calcular multa: " + diasParaCalcularMulta);
			
			devolucao.get().setStatusDevolucao(StatusDevolucao.ATRASADO);
			devolucao.get().setValorMulta((2 * diasParaCalcularMulta));
			update(devolucao.get());
			return true;
		}
		return false;
	}
	
	public boolean emAtraso2(Optional<Devolucao> devolucao) {
		Optional<Emprestimo> emprestimo = emprestimoRepository.findById(devolucao.get().getEmprestimo().getId());
		System.out.println("Data emprestimo: " + emprestimo.get().getDataEmprestimo());
		
		LocalDate dataDevolucao = LocalDate.parse(devolucao.get().getDataDevolucao().toString());
		LocalDate dataEmprestimo = LocalDate.parse(emprestimo.get().getDataEmprestimo().toString());
		
		int diasEmAtraso = calcularDiasDeAtraso(dataEmprestimo, dataDevolucao);
		
		if(diasEmAtraso > 3) {
			//System.out.println("Dias em atraso: " + diasEmAtraso);
			int diasParaCalcularMulta = diasEmAtraso - 3;
			//System.out.println("Dias para calcular multa: " + diasParaCalcularMulta);
			
			devolucao.get().setStatusDevolucao(StatusDevolucao.ATRASADO);
			devolucao.get().setValorMulta((2 * diasParaCalcularMulta));
			update(devolucao.get());
			return true;
		}
		return false;
	}
	
	public List<Devolucao> findByEmprestimoPessoaId(UUID id){
		return repository.findByEmprestimoPessoaId(id);
	}
	
	public List<Devolucao> buscarDevolucoesEmAtrasoPorIdDePessoa(UUID id){
		return repository.buscarDevolucoesEmAtrasoPorIdDePessoa(id);
	}
	
	public int calcularDiasDeAtraso(LocalDate dataEmprestimo, LocalDate dataDevolucao) {
		return (int) ChronoUnit.DAYS.between(dataEmprestimo, dataDevolucao);
	}
	
	public Devolucao update(Devolucao devolucao) {
		return repository.save(devolucao);
	}
	
	public boolean delete(UUID id) {
		repository.deleteById(id);
		return true;
	}
	
}

