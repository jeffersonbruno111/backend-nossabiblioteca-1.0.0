package br.fafic.ppi.biblioteca.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.fafic.ppi.biblioteca.model.Emprestimo;
import br.fafic.ppi.biblioteca.repository.EmprestimoRepository;

@Service
public class EmprestimoService {

	@Autowired
	private EmprestimoRepository repository;
	
	@Autowired
	private DevolucaoService devolucaoService;	
	
	public List<Emprestimo> findByEmprestimoAluno(String nome) throws Exception {
		List<Emprestimo> emprestTemp = new ArrayList<>();
		List<Emprestimo> m = repository.findByEmprestimoAluno(nome);
		System.out.println(Arrays.toString(m.toArray()));
		for(Emprestimo e: m) {
			if(verificarDevolucao(e.getId())) {
				emprestTemp.add(e);
			}
		}
		return emprestTemp;
	}
	
	public boolean verificarDevolucao(UUID uuid) {	
		System.out.println(repository.verificarDevolucao(uuid));
	return repository.verificarDevolucao(uuid) == null;
}
	
	public boolean save(Emprestimo emprestimo) {
		if(temPendencia(emprestimo.getPessoa().getId()) 
				|| existeExemplar(emprestimo)) {
			return false;
		}
		repository.save(emprestimo);
		return true;
	}
	
	public boolean temPendencia(UUID uuid) {
		if(devolucaoService.temPendencia(uuid) != null) {
			return true;
		}
		return false;
	}
	
	public boolean existeExemplar(Emprestimo emprestimo) {
		for(int i = 0; i < emprestimo.getLivros().size(); i++) {
				if(repository.recuperarQuantidadeDeExemplares(emprestimo.getId(), 
						emprestimo.getLivros().get(i).getId()) == 1) {
					System.out.println("Já existe um exemplar");
					return true;
				}
		}
		return false;
	}
	
	public long quantidadeLivros(UUID emprestimoId) {
		return repository.recuperarQuantidadeDeLivrosNoEmprestimo(emprestimoId);
	}
	
	public Optional<Emprestimo> findById(UUID id) {
		return repository.findById(id);
	}
	
	public List<Emprestimo> findAllByPessoaId(UUID id){
		return repository.findByPessoaId(id);
	}
	
	public List<Emprestimo> findAll(){
		return repository.findAll();
	}
	
	public Emprestimo update(Emprestimo emprestimo) {
		if(quantidadeLivros(emprestimo.getId()) > 3) {
			System.out.println("Não pode pegar mais livros");
			return null;
		}else {
			return repository.save(emprestimo);
		}
	}
	
	public boolean delete(UUID id) {
		repository.deleteById(id);
		return true;
	}
	
	public List<Emprestimo> findLivroByPessoaId(UUID id) {
		return repository.findLivroByPessoaId(id);
	}
	
}
