package br.fafic.ppi.biblioteca.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.fafic.ppi.biblioteca.model.Livro;
import br.fafic.ppi.biblioteca.repository.LivroRepository;

@Service
public class LivroService {

	@Autowired
	private LivroRepository repository;
	
	public Livro save(Livro livro) {
		return repository.save(livro);
	}
	
	public Optional<Livro> findById(UUID id) {
		return repository.findById(id);
	}
	
	public List<Livro> findAll(){
		return repository.findAll();
	}
	
	public Livro update(Livro livro) {
		return repository.save(livro);
	}
	
	public boolean delete(UUID id) {
		repository.deleteById(id);
		return true;
	}
	
	public Livro findByIsbn(String isbn) {
		return repository.findByIsbn(isbn);
	}
	
	public List<Livro> findAllByArea(Enum<?> area){
		return repository.findAllByArea(area);
	}
	
	public Livro findByNome(String nome) {
		return repository.findByNomeContaining(nome);
	}
	
	public int getQuantity(UUID id) {
		return repository.findQuantidadeById(id);
	}
}

