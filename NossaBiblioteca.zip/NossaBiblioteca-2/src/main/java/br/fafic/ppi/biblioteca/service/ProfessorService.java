package br.fafic.ppi.biblioteca.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.fafic.ppi.biblioteca.model.Professor;
import br.fafic.ppi.biblioteca.repository.ProfessorRepository;

@Service
public class ProfessorService {

	@Autowired
	private ProfessorRepository repository;
	
	public Professor save(Professor professor) {
		return repository.save(professor);
	}
	
	public Optional<Professor> findById(UUID id) {
		return repository.findById(id);
	}
	
	public Professor findByLoginMatricula(int matricula) {
		return repository.findByLoginMatricula(matricula);
	}
	
	public List<Professor> findAll(){
		return repository.findAll();
	}
	
	public Professor update(Professor professor) {
		return repository.save(professor);
	}
	
	public boolean delete(UUID id) {
		repository.deleteById(id);
		return true;
	}
}