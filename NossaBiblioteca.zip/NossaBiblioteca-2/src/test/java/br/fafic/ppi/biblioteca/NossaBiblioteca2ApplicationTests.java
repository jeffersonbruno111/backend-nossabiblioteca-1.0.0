package br.fafic.ppi.biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NossaBiblioteca2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
